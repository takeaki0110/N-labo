$(function(){
 $('#menu').slicknav();
});

 $(function(){
    $('.slicknav_menu').prepend('<h1><a href="#">LOGO</a></h1>');
});